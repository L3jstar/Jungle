package project.src.view.ChessComponent;

import project.src.model.PlayerColor;

import javax.swing.*;
import java.awt.*;

/**
 * This is the equivalent of the ChessPiece class,
 * but this class only cares how to draw Chess on ChessboardComponent
 */
public class RatChessComponent extends ChessComponent {
    private PlayerColor owner;
    private boolean selected;
    int size;

    public RatChessComponent(PlayerColor owner, int size) {
        this.owner = owner;
        this.selected = false;
        this.size=size;
        setSize(size/2, size/2);
        setLocation(0,0);
        setVisible(true);
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        ImageIcon picture = new ImageIcon("redRat.jpg");
        if (owner == PlayerColor.BLUE){
            picture = new ImageIcon("blueRat.jpg");
        }
        Image image = picture.getImage();
        picture = new ImageIcon(image.getScaledInstance(size,size,Image.SCALE_SMOOTH));
        JLabel label = new JLabel(picture);
        label.setSize(size, size);
        label.setLocation(0, 0);
        add(label);
//        super.paintComponent(g);
//        Graphics2D g2 = (Graphics2D) g;
//        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//        Font font = new Font("楷体", Font.PLAIN, getWidth() / 2);
//        g2.setFont(font);
//        g2.setColor(owner.getColor());
//        g2.drawString("鼠", getWidth() / 4, getHeight() * 5 / 8); // FIXME: Use library to find the correct offset.这里要写偏移量（根据棋子定）
//        if (isSelected()) { // Highlights the model if selected.
//            g.setColor(Color.PINK);//本来是RAD
//            g.drawOval(0, 0, getWidth() , getHeight());//有可能要写东西
//        }
    }
}
