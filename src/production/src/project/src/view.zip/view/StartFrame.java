package project.src.view;
import project.src.controller.GameController;
import project.src.model.Chessboard;
import javax.swing.*;
import java.awt.*;
public class StartFrame extends JFrame{
    ChessGameFrame chessGameFrame;
    private final int WIDTH;
    private final int HEIGHT;

    public StartFrame(){
        setTitle("斗兽王");
        this.WIDTH=400;
        this.HEIGHT=500;
        setSize(WIDTH,HEIGHT);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);

        ChessGameFrame chessGameFrame=new ChessGameFrame(1100,810);
        GameController controller = new GameController(chessGameFrame.getChessboardComponent(), new Chessboard());
        this.chessGameFrame=chessGameFrame;
        chessGameFrame.startFrame=this;

        addStartButton();

        Image picture = new ImageIcon("startFrame.jpg").getImage();
        picture = picture.getScaledInstance(400, 500,Image.SCALE_DEFAULT);
        ImageIcon icon = new ImageIcon(picture);
        JLabel start = new JLabel(icon);
        start.setSize(400, 500);
        start.setLocation(0, 0);
        add(start);

    }

    private void addStartButton(){
        JButton button=new JButton("Start");

        button.addActionListener((e) -> {
//            this.setVisible(false);
//            Timer.time = 45;
//            if (Controller.timer == null){
//                Controller.timer = new Timer(gameFrame.getBoardView().controller);
//                Controller.timer.start();
//            }

            chessGameFrame.statusLabel.setLocation(770, 81);
            chessGameFrame.repaint();
            chessGameFrame.getChessboardComponent().GameController.restart();
            chessGameFrame.setVisible(true);
        });

        button.setLocation(100,100);
        button.setSize(180,50);
        button.setFont(new Font("Rockwell", Font.BOLD, 20));
        add(button);
    }
    static class ImageComponent extends JComponent {
        Image paintImage;

        public ImageComponent(Image picture) {
            this.setLayout(null);
            this.setFocusable(true);//Sets the focusable state of this Component to the specified value. This value overrides the Component's default focusability.
            this.paintImage = picture;
            repaint();//execute the paintComponent method
        }

        // the method describes how to paint, and being invoked by repaint() method.
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(paintImage, 0, 0, paintImage.getWidth(this), paintImage.getHeight(this), this);
        }
    }
}
